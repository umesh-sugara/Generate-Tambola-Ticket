from flask import Flask, jsonify, request,render_template
import database
import json

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# http://127.0.0.1:5000/database/fetch_top_60_tickets
@app.route('/database/fetch_top_60_tickets')
def total_60():
    # Fetch the JSON data from the database
    json_string = database.fetch_top_60_tickets()
    
    # Parse the JSON string into a Python dictionary
    data = json.loads(json_string)
    
    # Return the JSON data as a response
    return jsonify(data)

# http://127.0.0.1:5000/database/fetch_all_tickets?page=3&size=10
@app.route('/database/fetch_all_tickets')
def fetch_all_tickets():
    # Get query parameters for pagination
    page_number = int(request.args.get('page', 1))
    page_size = int(request.args.get('size', 10))  # Default page size is 10

    # Fetch all tickets from the database
    json_string = database.fetch_all_tickets(page_number, page_size)
    
    # Parse the JSON string into a Python dictionary
    data = json.loads(json_string)

    # Return the JSON data as a response
    return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True)
