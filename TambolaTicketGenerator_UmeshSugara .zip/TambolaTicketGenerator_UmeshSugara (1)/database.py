import json
import pyodbc
import random
import numpy as np
import time
import random
import copy
import pandas as pd



GLOBAL_DICT = {
    '0-9': set(range(1, 10)), # for logical implementation naming is done 0-9. range is from (1,10)
    '10-19': set(range(10, 20)),
    '20-29': set(range(20, 30)),
    '30-39': set(range(30, 40)),
    '40-49': set(range(40, 50)),
    '50-59': set(range(50, 60)),
    '60-69': set(range(60, 70)),
    '70-79': set(range(70, 80)),
    '80-89': set(range(80, 91))  # for logical implementation naming is done 80-89. range is from (80,91)
}

try:
    with open('appsettings.json', 'r') as f:
        config = json.load(f)

    db_config = config['database']

    connection = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        f'SERVER={db_config["server"]};'
        f'DATABASE={db_config["database"]};'
        f'UID={db_config["username"]};'
        f'PWD={db_config["password"]}'
    )

    cursor = connection.cursor()

    # Check if the table exists
    cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TambolaTicket'")
    if cursor.fetchone()[0] == 0:
        # Table does not exist, create it
        cursor.execute("""
            CREATE TABLE TambolaTicket (
                id INT IDENTITY(1,1) PRIMARY KEY,
                setid INT,
                ticket NVARCHAR(255)
            )
        """)          
        connection.commit()
        # print("TambolaTicket table created successfully.")
    else:
        print("TambolaTicket table already exists.")

except Exception as error:
     print("Error while connecting to SQL Server or creating TambolaTicket table", error)
     raise
    


def reshape_string_to_ticket(flat_ticket_str):
    # Convert the string back into a list
    flat_ticket = list(map(int, flat_ticket_str.split(',')))
    # Reshape the list into a 3x9 matrix
    ticket = np.reshape(flat_ticket, (3, 9)).tolist()
    # print(ticket)
    return ticket




def fetch_all_tickets(page_number=1, page_size=10):
    # Calculate the offset for pagination
    offset = (page_number - 1) * page_size
    cursor.execute(f"SELECT * FROM TambolaTicket ORDER BY ID OFFSET {offset} ROWS FETCH NEXT {page_size} ROWS ONLY")


    # Fetch all rows
    rows = cursor.fetchall()

    # Initialize a list to hold all tickets
    all_tickets = []

    for row in rows:
        # Reshape the ticket
        ticket = reshape_string_to_ticket(row[2])

        # Create a dictionary to hold ticket information
        ticket_info = {
            "ID": row[0],
            "Set_ID": row[1],
            "Ticket": ticket
        }

        # Append the ticket information to the list
        all_tickets.append(ticket_info)

    # Convert the list of dictionaries to JSON format
    json_data = json.dumps(all_tickets, indent=4)
    return json_data


def fetch_top_60_tickets():
    cursor.execute("SELECT top 60 * FROM TambolaTicket ORDER BY 2")
    rows = cursor.fetchall()
    
    alldata = {"tickets": {}}
    for row in rows:
        ticket = reshape_string_to_ticket(row[2])
        ticket_string = str(ticket)
        alldata["tickets"][str(row[0])] = ticket
    
    # Convert the dictionary to a JSON string
    json_data = json.dumps(alldata)
    print(json_data)
    
    return json_data


def select_15(Num_dict):
    ticket = [[0] * 9 for _ in range(3)]
    mapping = {
        '0-9': 1,
        '10-19': 2,
        '20-29': 3,
        '30-39': 4,
        '40-49': 5,
        '50-59': 6,
        '60-69': 7,
        '70-79': 8,
        '80-89': 9
    }

    sorted_dict = sorted(Num_dict.items(), key=lambda item: len(item[1]))

    col_numbers = []

    selected_numbers_dict = {}

    count = 1

    for key, values in sorted_dict:
        if count < 4:
            num_to_select = 1
        else:
            num_to_select = 2
        count += 1
        col = mapping[key] - 1
        selected_elements = random.sample(list(values), min(num_to_select, len(values)))
        col_numbers.extend(selected_elements)
        selected_numbers_dict[mapping[key]] = copy.deepcopy(selected_elements)
        
        # Remove selected numbers from Num_dict
        for element in selected_elements:
            values.remove(element)

    return sorted(col_numbers)

def plainTicket(numbers):
    max_values = [10, 20, 30, 40, 50, 60, 70, 80, 91]
    matrix = [[0] * 9 for _ in range(3)]
    rowNum = {0: 5, 1: 5, 2: 5}
    colNum = 0
    getRow = []
    getNums = []

    for _ in range(9):
        # Filter numbers less than max_values[colNum]
        while numbers and numbers[0] < max_values[colNum]:
            getNums.append(numbers.pop(0))
        
        # Extract rows from rowNum
        for key in sorted(rowNum.keys(), key=lambda x: rowNum[x], reverse=True):
            if rowNum[key] > 0:
                getRow.append(key)
                rowNum[key] -= 1
                if len(getRow) >= len(getNums):
                    break

        # Sort getRow
        getRow.sort()

        # Populate matrix
        for i, num in enumerate(getNums):
            matrix[getRow[i]][colNum] = num

        # Clear getRow and getNums for the next iteration
        getRow.clear()
        getNums.clear()

        colNum += 1

    return matrix

def reshape_matrix_to_string(ticket):
    flattened_matrix = [str(element) for row in ticket for element in row]
    comma_separated_string = ','.join(flattened_matrix)
    return comma_separated_string

def updateNumberDict(valuesList, Number_dict):
    for value in valuesList:
        if value == 90:  # Handle the special case when value is 90
            key = "80-89"
        else:
            quotient = value // 10
            key = f"{(quotient * 10 + 1) - 1}-{((quotient + 1) * 10) - 1}" 
        Number_dict.setdefault(key, set()).add(value)


def setTicket(setid):
    setList = []
    counter =3
    Number_dict = copy.deepcopy(GLOBAL_DICT)
    while len(setList) < 6:
        # print("\n\nCurrent Number dict:",len(setList)+1,'\n\n')
        # for key, values in Number_dict.items():
        #     print(f"{key}: {values}")
        removedList = select_15(Number_dict)
        finalTicket = plainTicket(removedList)
        # print(f'\nThis is your ticket : {len(setList)+1} \n')
        # for row in finalTicket:
        #     print(row)
        finalTicket = reshape_matrix_to_string(finalTicket)
        if finalTicket not in cursor.execute("SELECT ticket FROM TambolaTicket") and counter>0:
            setList.append(finalTicket)
        elif counter>0:
            counter-=1
            updateNumberDict(removedList)
        else:
            return 0
    if len(setList)==6:
        for ticket in setList:
            cursor.execute(f"INSERT INTO TambolaTicket (setid, ticket) VALUES ({setid}, '{ticket}')")
    connection.commit()
    return 1


def printTicket(setid):
    # Execute the SELECT statement
    cursor.execute(f"SELECT * FROM TambolaTicket where setid ={setid}")
    # Fetch all rows
    rows = cursor.fetchall()
    # Print all tickets
    for row in rows:
        # Reshape the ticket
        ticket = reshape_string_to_ticket(row[2])
        # Print ticket in 2D format
        print(f"ID: {row[0]}, Set ID: {row[1]}")
        for line in ticket:
            print(line)
        print()  




if __name__ == "__main__":
    try:
        with open('appsettings.json', 'r') as f:
            config = json.load(f)

        # totalTicketSets = config['initial_set_count']
        # print('Generating Your Tickets...')
        # start_time = time.time()
        # sets =1
        # while sets <=totalTicketSets:
        #     sets+=setTicket(sets)
        # end_time = time.time()
        # total_time = end_time - start_time
        # print(f"Total time taken for {totalTicketSets} iterations:", total_time, "seconds")
        # fetch_all_tickets()
        printTicket(4)
        # fetch_top_60_tickets()

    except Exception as e:
        print("An error occurred:", e)
    finally:
        cursor.close()
        connection.close()